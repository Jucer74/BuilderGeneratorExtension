﻿namespace BuilderGeneratorExtension
{
   [Command(PackageIds.BuilderCommand)]
   internal sealed class BuilderCommand : BaseCommand<BuilderCommand>
   {
      protected override async Task ExecuteAsync(OleMenuCmdEventArgs e)
      {
         await VS.MessageBox.ShowWarningAsync("BuilderGeneratorExtension", "Button clicked");
      }
   }
}
